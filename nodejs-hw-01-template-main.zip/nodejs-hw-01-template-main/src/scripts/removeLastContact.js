export const removeLastContact = async () => {};

removeLastContact();
