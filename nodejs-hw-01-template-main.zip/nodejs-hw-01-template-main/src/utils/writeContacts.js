import { PATH_DB } from '../constants/contacts.js';

export const writeContacts = async (updatedContacts) => {};
