export const addOneContact = async () => {};

addOneContact();
