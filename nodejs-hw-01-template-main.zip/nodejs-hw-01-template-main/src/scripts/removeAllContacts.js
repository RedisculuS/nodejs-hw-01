export const removeAllContacts = async () => {};

removeAllContacts();
