export const countContacts = async () => {};

console.log(await countContacts());
