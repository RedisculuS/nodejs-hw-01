import { PATH_DB } from '../constants/contacts.js';

export const readContacts = async () => {};
