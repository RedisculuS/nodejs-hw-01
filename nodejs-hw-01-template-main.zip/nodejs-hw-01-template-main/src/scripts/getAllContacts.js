export const getAllContacts = async () => {};

console.log(await getAllContacts());
