const generateContacts = async (number) => {};

generateContacts(5);
